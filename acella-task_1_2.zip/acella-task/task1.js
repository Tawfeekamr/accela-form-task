
// Q1. Below is a JavaScript program that should display a message after a delay of 1 second, but it doesn't
// work.
// showMessage("Hello");
// function showMessage(msg){
//     setTimeout(showAlertBox, 1000);
// }
// function showAlertBox (){
//     alert(msg);
// }

// A1. 1st Method
var msg = "Hello";

showMessage(msg);
function showMessage(){
    setTimeout(showAlertBox, 1000);
}
function showAlertBox(){
    alert(msg);
}