
// Q1. Below is a JavaScript program that should display a message after a delay of 1 second, but it doesn't
// work.
// showMessage("Hello");
// function showMessage(msg){
//     setTimeout(showAlertBox, 1000);
// }
// function showAlertBox (){
//     alert(msg);
// }


// A2. 2nd Method
var msg = "Hello";

showMessage();
function showMessage(){
    setTimeout(function () {
        console.log(msg);
    }, 1000);
}
